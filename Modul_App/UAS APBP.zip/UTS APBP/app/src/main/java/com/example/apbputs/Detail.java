package com.example.apbputs;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class Detail extends AppCompatActivity {
    private String username;
    private TextView greeting_user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        Intent intent = getIntent();
        String username = intent.getStringExtra("key_username");

        greeting_user = findViewById(R.id.greeting_user);

        greeting_user.setText("Halo, " + username);

        try {
            URL uri = new URL("http://103.56.149.20/~itslear/api/panggil_produk.php");
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

//        Data[] data = new Data[] {
//                new Data(R.drawable.oyen, "Kocheng Oyen", "Ras terkuat di Jawa"),
//                new Data(R.drawable.kochng_hitam, "Kocheng Hitam", "N*gga cat"),
//                new Data(R.drawable.tiga_warna, "Kocheng 3 Warna", "Rare cat"),
//                new Data(R.drawable.anggora, "Kocheng Anggora", "Ucing juragan, babunya hooman"),
//                new Data(R.drawable.jowo, "Kocheng Jowo", "Javanese cat, sugeng rawuh"),
//                new Data(R.drawable.index, "Pussy", "Ini tidak seperti yang Anda pikirkan"),
//        };

        AndroidNetworking.get(Endpoint.GET_PRODUCT)
                .setPriority(Priority.HIGH)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        ArrayList<Data> arrayList = new ArrayList<>();

                        try {
                            JSONArray list = response.getJSONArray("result");

                            for (int i = 0; i<list.length(); i++) {
                                JSONObject object = list.getJSONObject(i);
                                Data data_single = new Data(
                                        R.drawable.burger,
                                        object.get("name").toString(),
                                        object.get("desc").toString(),
                                        Integer.parseInt(object.get("price").toString()));
                                System.out.println(data_single);
                                arrayList.add(data_single);
                            }

                            RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
                            MyAdapterList adapter = new MyAdapterList(arrayList);
                            recyclerView.setHasFixedSize(true);
                            recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                            recyclerView.setItemAnimator(new DefaultItemAnimator());
                            recyclerView.setAdapter(adapter);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onError(ANError anError) {
                        System.out.println("error: ");
                        System.out.println(anError.getErrorDetail());
                        System.out.println("error code: " + anError.getErrorCode());
                        System.out.println(anError.toString());
                        Toast.makeText(getApplicationContext(), anError.toString(), Toast.LENGTH_LONG).show();
                    }
                });
    }
}