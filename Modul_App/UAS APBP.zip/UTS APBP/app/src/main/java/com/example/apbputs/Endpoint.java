package com.example.apbputs;

public class Endpoint {
    public static final String BASE_URL = "http://103.56.149.20/~itslear/api/";
    public static final String CEK_LOGIN = BASE_URL + "panggil_data.php";
    public static final String GET_PRODUCT =  BASE_URL + "panggil_produk.php";
}
