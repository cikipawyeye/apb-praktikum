package com.example.apbputs;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class MainActivity extends AppCompatActivity {
    private String username, password;
    EditText edUsername, edPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        AndroidNetworking.initialize(getApplicationContext());

        edUsername = findViewById(R.id.username);
        edPassword = findViewById(R.id.password);
        Button btnLogin = findViewById(R.id.btn_login);

        btnLogin.setOnClickListener(view -> {
            username = edUsername.getText().toString();
            password = edPassword.getText().toString();

            cekLogin(username, password);

        });
    }

    private void cekLogin(String username, String password) {
        AndroidNetworking.post(Endpoint.CEK_LOGIN)
                .addBodyParameter("username", "admin")
                .setPriority(Priority.HIGH)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            System.out.println("gak error awokawok: ");
                            JSONArray list = response.getJSONArray("result");
                            for (int i = 0; i<list.length(); i++) {
                                JSONObject object = list.getJSONObject(i);
                                if (object.get("username").equals(username)) {
                                    System.out.println(object.get("username").toString());
                                    Intent intent = new Intent(MainActivity.this, Detail.class);
                                    intent.putExtra("key_username", object.get("username").toString());
                                    startActivity(intent);
                                    break;
                                }

                                if (i == list.length() - 1) {
                                    Toast.makeText(getApplicationContext(), "Username salah!", Toast.LENGTH_LONG).show();
                                }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onError(ANError anError) {
                        System.out.println("error: ");
                        System.out.println(anError.getErrorDetail());
                        System.out.println("error code: " + anError.getErrorCode());
                        System.out.println(anError.toString());
                        Toast.makeText(getApplicationContext(), anError.toString(), Toast.LENGTH_LONG).show();
                    }
                });
    }
}