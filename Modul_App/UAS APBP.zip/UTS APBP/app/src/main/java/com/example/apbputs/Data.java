package com.example.apbputs;

public class Data {
    private int imageView;
    private String title;
    private String desc;
    private int price;

    public Data(int imageView, String title, String desc, int price) {
        this.imageView = imageView;
        this.price = price;
        this.title = title;
        this.desc = desc;
    }


    public int getPrice() { return price; }

    public void setPrice(int price) { this.price = price; }

    public int getImageView() {
        return imageView;
    }

    public void setImageView(int imageView) {
        this.imageView = imageView;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    @Override
    public String toString() {
        return "Data{" +
                "imageView=" + imageView +
                ", title='" + title + '\'' +
                ", desc='" + desc + '\'' +
                ", price=" + price +
                '}';
    }
}
